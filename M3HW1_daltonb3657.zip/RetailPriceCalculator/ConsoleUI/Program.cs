﻿/*
 * 2/23/2020
 * CSC 153
 * Brandon Dalton
 * This program accepts a wholesale cost and a markup percentage and returns the retail price
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            String input;
            double cost=0, percentage=0,number=0;
            do
            {
                Console.Write(ClassLibrary.StandardMessages.CostInput());
                input = Console.ReadLine();
                if (double.TryParse(input, out cost))
                {
                    //Parses correctly and stores number to variable cost
                }
                else
                {
                    Console.WriteLine("Not a valid number!");
                    input = null;
                }
            } while (input == null);
            do
            {
                Console.Write(ClassLibrary.StandardMessages.PercentageInput());
                input = Console.ReadLine();
                if (double.TryParse(input, out number))
                {
                    percentage = number / 100;
                }
                else
                {
                    Console.WriteLine("Not a valid number!");
                    input = null;
                }
            } while (input == null);


            Console.WriteLine(ClassLibrary.StandardMessages.RetailPriceMessage() + CalculateReatil(cost, percentage));
            Console.ReadLine();

        }

        public static double CalculateReatil(double cost, double percentage)
        {
            return (cost * percentage) + cost;
        }
    }
}
