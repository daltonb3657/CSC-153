﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class StandardMessages
    {
        public static string CostInput()
        {
            return "What is the cost of the item? ";
        }
        public static string PercentageInput()
        {
            return "What is the markup percentage? ";
        }
        public static string RetailPriceMessage()
        {
            return "The retail price is - ";
        }
    }
}
