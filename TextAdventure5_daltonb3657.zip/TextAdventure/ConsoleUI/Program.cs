﻿/**
* 3/1/20
* CSC 153
* Brandon Dalton
* Text based adventure, program will simulate a text based adventure
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TextAdventureLib;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            Room[] rooms = {new Room("Entrance", "Dungeon entrance"), new Room("Hallway","Connects rooms"), new Room("Red Room","Room with Red walls"), new Room("Blue Room","Room with Blue walls"), new Room("Black Room","Room that is pitch black")};
            Weapon[] weapons = {new Weapon("Dagger",100,5), new Weapon("Long Sword",100,15), new Weapon("Scythe",100,8) , new Weapon("Great Sword",100,30) };
            Potion[] potions = {new Potion("Vitality Potion","Recovers health"), new Potion("Mind Potion", "Recovers mana") };
            Treasure[] treasures = {new Treasure("Emerald"), new Treasure("Diamond"), new Treasure("Ruby") };
            List<Item> items = new List<Item>();
            List<Mob> mobs = new List<Mob>();
            List<Player> players = new List<Player>(); 
            int position = 0;
            int health = 100;
            String input;
            items.Add(new Item("Key"));
            items.Add(new Item("Lock Pick"));
            items.Add(new Item("Whetstone"));
            items.Add(new Item("Smoke Bomb"));            
            mobs.Add(new Mob("Slime",30,2));
            mobs.Add(new Mob("Dire Wolf",50,5));
            mobs.Add(new Mob("Goblin",80,10));
            mobs.Add(new Mob("Witch",100, 15));
            mobs.Add(new Mob("Zombie",15,30));

            
            do
            {
                Console.WriteLine(StandardMessages.Menu());
                input = Console.ReadLine();
                
                switch(input)
                {
                    case "1":
                        BuildPlayer.BuildAPlayer(players);
                        Console.WriteLine("");
                        break;
                    case "2":
                        MoveNorth(ref position);
                        Console.WriteLine("");
                        break;
                    case "3":
                        MoveSouth(ref position);
                        Console.WriteLine("");
                        break;
                    case "4":                        
                        Console.WriteLine($"Health remaining {Attack(ref health)}");
                        Console.WriteLine("");
                        break;
                    case "5":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine(StandardMessages.MenuError());
                        Console.WriteLine("");
                        break;
                }               
            } while (exit == false);

        }
        
        public static void MoveNorth(ref int position)
        {
            if(position !=4)
            {
                position++;
                Console.WriteLine(StandardMessages.RoomMove() + position);

            }
            else
            {
                Console.WriteLine("You are at the end of the dungeon and cannot progress any further.");
            }
        }

        public static void MoveSouth(ref int position)
        {
            if(position !=0)
            {
                position = position - 1;
                Console.WriteLine(StandardMessages.RoomMove() + position);
            }
            else
            {
                Console.WriteLine("You are at the start and cannot move further back.");
            }

        }

        public static int Attack(ref int health)
        {
            Random random = new Random();
            int attack = random.Next(1,21);
            health = health - attack;            
            return health;
        }
                
             
    }
}
