﻿/**
* 4/26/20
* CSC 153
* Brandon Dalton
* Program holds customer information
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PersonAndCustomerLib;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer newCustomer = new Customer("Bob","123 Lane Ln.","29292929292","0001",true);

            Console.WriteLine($"Name - {newCustomer.Name}, Address - {newCustomer.Address}, Phone Number - {newCustomer.PhoneNumber}, Customer Number - {newCustomer.CustomerNumber}, Mailing List - {newCustomer.MailingList} ");


            Console.ReadLine();
        }
    }
}
