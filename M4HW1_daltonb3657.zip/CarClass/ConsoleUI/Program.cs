﻿/**
* 3/18/20
* CSC 153
* Brandon Dalton
* Creates a car class and demontrates it
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            CarClassLib.Car car = new CarClassLib.Car();
            do
            {
                Console.WriteLine(CarClassLib.StandardMessages.DisplayMenu());

                switch (Console.ReadLine())
                {
                    case "1":
                        Console.WriteLine(CarClassLib.StandardMessages.CarMake()); 
                        car.Make = Console.ReadLine();
                        Console.WriteLine(CarClassLib.StandardMessages.CarYear());
                        car.Year = Console.ReadLine();
                        Console.WriteLine("");
                        break;
                    case "2":
                        car.Accelerate();
                        Console.WriteLine(CarClassLib.StandardMessages.DisplayCarSpeed(car));
                        Console.WriteLine("");
                        break;
                    case "3":
                        if(CarClassLib.Car.Speed <= 0)
                        {
                            Console.WriteLine(CarClassLib.StandardMessages.DisplaySpeedError());
                            Console.WriteLine();
                        }
                        else
                        {
                            car.Brake();
                            Console.WriteLine(CarClassLib.StandardMessages.DisplayCarSpeed(car));
                            Console.WriteLine("");
                        }                        
                        break;
                    case "4":
                        exit = true;
                        break;
                    default:
                        CarClassLib.StandardMessages.DisplayErrorChoice();
                        break;
                }

            } while (exit == false);
        }
    }
}
