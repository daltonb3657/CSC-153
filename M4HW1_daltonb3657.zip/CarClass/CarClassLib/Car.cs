﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClassLib
{
    public class Car
    {
        private string _year;
        private string _make;

        public Car()
        {
            Year = "";
            Make = "";
            Speed = 0;
            
        }

        public Car(string year, string make)
        {
            Year = year;
            Make = make;
            Speed = 0;
            
        }

        public string Year
        {
            get
            {
                return _year;
            }
            set
            {
                _year = value;
            }
        }

        public string Make
        {
            get
            {
                return _make;
            }
            set
            {
                _make = value;
            }
        }

        public static int Speed { get; set; }

        public int Accelerate()
        {
            Speed = Speed + 5;
            return Speed;
        }
        public int Brake()
        {
            Speed = Speed - 5;
            return Speed;
        }

    }

    
}
