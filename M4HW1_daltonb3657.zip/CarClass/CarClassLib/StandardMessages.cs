﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarClassLib
{
    public static class StandardMessages
    {
        public static string DisplayMenu()
        {
            return "1. Create Car\n2. Accelerate\n3. Brake\n4. exit\n-->";
        }
        public static string CarMake()
        {
            return "What is your car's make?";
        }
        public static string CarYear()
        {
            return "What is your car's year?";
        }
        public static string DisplayErrorChoice()
        {
            return "Not a valid choice!";
        }
        public static string DisplaySpeedError()
        {
            return "The car can't go any slower!";
        }
        public static string DisplayCarSpeed(Car car)
        {
            return $"Car Make - {car.Make}\nCar Year - {car.Year}\nCar speed - {Car.Speed}";
        }

    }
}
