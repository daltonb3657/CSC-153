﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class StandardMessages
    {
        public static string ErrorMessage()
        {
            return "Error invalid input!";
        }

        public static string FallingTime()
        {
            return "Enter the amount of time in seconds the object is falling. ";
        }

        public static string FallingDistance()
        {
            return "Distance the object has fallen - ";
        }
    }
}
