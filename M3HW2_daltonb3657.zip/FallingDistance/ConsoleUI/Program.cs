﻿/*
 * 2/23/2020
 * CSC 153
 * Brandon Dalton
 * This program accepts the time an object spent falling and returns the distance it fell.
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            double time=0;
            do
            {
                Console.Write(ClassLibrary.StandardMessages.FallingTime());
                input = Console.ReadLine();
                if (double.TryParse(input, out time))
                {
                    //no errors, assigns input to time
                }
                else
                {
                    Console.WriteLine(ClassLibrary.StandardMessages.ErrorMessage());
                }
            } while (time == 0);
            Console.WriteLine(ClassLibrary.StandardMessages.FallingDistance() + FallingDistance(time) + " meters");
            Console.ReadLine();

        }
        public static double FallingDistance(double input)
        {
            double output = .5 * 9.8 * Math.Pow(input, 2);
            return output;
        }
    }
}
