﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAdventureLib
{
    public class Player
    {
        // Fields
        private string _name;
        private string _password;
        private string _class;
        private string _race;

        // Constructor
        public Player()
        {
            Name = "No name";
            Password = "No password";
            Class = "No class";
            Race = "No race";
        }

        public Player(string name, string password, string clas, string race)
        {
            Name = name;
            Password = password;
            Class = clas;
            Race = race;
        }

        // Property
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                
                _name = value;
            }
        }

        public string Password
        {
            get
            {
                return _password;
            }
            set
            {
                _password = value;
            }
        }

        public string Class
        {
            get
            {
                return _class;
            }
            set
            {
                _class = value;
            }
        }

        public string Race
        {
            get
            {
                return _race;
            }
            set
            {
                _race = value;
            }
        }
    }
}
