﻿/**
* 3/1/20
* CSC 153
* Brandon Dalton
* Text based adventure, program will simulate a text based adventure
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            String[] rooms = {"Entrance", "Hallway", "Red Room", "Blue Room", "Black Room" };
            String[] weapons = {"Dagger", "Long Sword", "Scythe" , "Great Sword" };
            String[] potions = {"Vitality Potion", "Mind Potion" };
            String[] treasures = {"Emerald", "Diamond", "Ruby" };
            List<String> items = new List<string>();
            List<String> mobs = new List<string>();
            int position = 0;
            int health = 100;
            String input;
            items.Add("Key");
            items.Add("Lock Pick");
            items.Add("Whetstone");
            items.Add("Smoke Bomb");            
            mobs.Add("Slime");
            mobs.Add("Dire Wolf");
            mobs.Add("Goblin");
            mobs.Add("Witch");
            mobs.Add("Zombie");

            
            do
            {
                Console.WriteLine(TextAdventureLib.StandardMessages.Menu());
                input = Console.ReadLine();
                
                switch(input)
                {
                    case "1":
                        MoveNorth(ref position);
                        Console.WriteLine("");
                        break;
                    case "2":
                        MoveSouth(ref position);
                        Console.WriteLine("");
                        break;
                    case "3":                        
                        Console.WriteLine($"Health remaining {Attack(ref health)}");
                        Console.WriteLine("");
                        break;
                    case "4":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine(TextAdventureLib.StandardMessages.MenuError());
                        Console.WriteLine("");
                        break;
                }               
            } while (exit == false);

        }
        
        public static void MoveNorth(ref int position)
        {
            if(position !=4)
            {
                position++;
                Console.WriteLine(TextAdventureLib.StandardMessages.RoomMove() + position);

            }
            else
            {
                Console.WriteLine("You are at the end of the dungeon and cannot progress any further.");
            }
        }

        public static void MoveSouth(ref int position)
        {
            if(position !=0)
            {
                position = position - 1;
                Console.WriteLine(TextAdventureLib.StandardMessages.RoomMove() + position);
            }
            else
            {
                Console.WriteLine("You are at the start and cannot move further back.");
            }

        }

        public static int Attack(ref int health)
        {
            Random random = new Random();
            int attack = random.Next(1,21);
            health = health - attack;            
            return health;
        }
                
             
    }
}
