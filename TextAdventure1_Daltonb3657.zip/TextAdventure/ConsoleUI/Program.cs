﻿/**
* 2/9/20
* CSC 153
* Brandon Dalton
* Text based adventure, program will simulate a text based adventure
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            String[] rooms = {"Entrance", "Hallway", "Red Room", "Blue Room", "Black Room" };
            String[] weapons = {"Dagger", "Long Sword", "Scythe" , "Great Sword" };
            String[] potions = {"Vitality Potion", "Mind Potion" };
            String[] treasures = {"Emerald", "Diamond", "Ruby" };
            List<String> items = new List<string>();
            List<String> mobs = new List<string>();
            int position=0;
            String input, prompt;
            items.Add("Key");
            items.Add("Lock Pick");
            items.Add("Whetstone");
            items.Add("Smoke Bomb");            
            mobs.Add("Slime");
            mobs.Add("Dire Wolf");
            mobs.Add("Goblin");
            mobs.Add("Witch");
            mobs.Add("Zombie");

            Console.WriteLine($"You are here: {rooms[position]}");
            do
            {
                Console.WriteLine("What would you like to do?(Enter options if you are new and need a list of options.) ");
                input = Console.ReadLine();
                input = input.ToLower();

                while (!(input.Equals("north") || input.Equals("n") || input.Equals("south") || input.Equals("s") || input.Equals("main menu") || input.Equals("position") || input.Equals("options")))
                {
                    Console.WriteLine("Invalid input!\n If you would like a list of options please type options. ");
                    Console.WriteLine("What would you like to do?");
                    input = input.ToLower();
                }
                if (input.Equals("options"))
                {
                    options();
                }
                if (input.Equals("position"))
                {
                    Console.WriteLine($"You are here: {rooms[position]}");
                }
                if (input.Equals("north") && position !=4 || input.Equals("n") && position !=4)
                {
                    position = position + 1;
                    Console.WriteLine($"You have entered {rooms[position]}");
                }
                if (input.Equals("north") && position == 4 || input.Equals("n") && position == 4)
                {
                    Console.WriteLine($"You are at {rooms[position]}. This is the final room and you can not progress further.");
                }

                if (input.Equals("south") && position !=0 || input.Equals("s") && position != 0)
                {
                    position = position - 1;
                    Console.WriteLine($"You have entered {rooms[position]}");
                }
                if (input.Equals("south") && position ==0 || input.Equals("s") && position == 0)
                {
                    Console.WriteLine($"You are at {rooms[position]}, you cannot move further back.");
                }
                if (input.Equals("main menu"))
                {
                    mainMenu(rooms, weapons, potions, treasures, items, mobs);
                }

                Console.WriteLine("Would you like to continue or save and exit?");
                prompt = Console.ReadLine();
                prompt = prompt.ToLower();
                while(!(prompt.Equals("continue") || prompt.Equals("save and exit")))
                {
                    Console.WriteLine("Invalid input!\n If you wish to continue enter 'Continue'. If you wish to save and exit enter 'Save and exit'. ");
                    prompt = Console.ReadLine();
                    prompt = prompt.ToLower();
                }
            } while (prompt.Equals("continue"));

        }

        public static void mainMenu(String[] rooms, String[] weapons, String[] potions, String[] treasures, List<String> items, List<String> mobs)
        {
            String input=null;
            int choice=0;
            Console.WriteLine("Choose an option:" +
                    "\n1.Display Rooms" +
                    "\n2.Display Weapon" +
                    "\n3.Display Potion" +
                    "\n4.Display Treasure" +
                    "\n5.Display Items" +
                    "\n6.Display Mobs" +
                    "\n7.Exit");
            while (input == null)
            {
                try
                {
                    input = Console.ReadLine();
                    choice = int.Parse(input);
                }
                catch (FormatException e)
                {
                    Console.WriteLine("Error! Invalid input! Please enter a number from the menu.");
                    input = null;
                }
            }
            switch (choice)
            {
                case 1:
                    Console.WriteLine("Rooms: ");
                    for (int i = 0; i < rooms.Length; i++)
                    {
                        Console.WriteLine(rooms[i]);
                    }
                    break;
                case 2:
                    Console.WriteLine("Weapons: ");
                    Array.Sort(weapons);
                    for (int i = 0; i < weapons.Length; i++)
                    {
                        Console.WriteLine(weapons[i]);
                    }
                    break;
                case 3:
                    Console.WriteLine("Potions: ");
                    for (int i = 0; i < potions.Length; i++)
                    {
                        Console.WriteLine(potions[i]);
                    }
                    break;
                case 4:
                    Console.WriteLine("Treasures: ");
                    for (int i = 0; i < treasures.Length; i++)
                    {
                        Console.WriteLine(treasures[i]);
                    }
                    break;
                case 5:
                    Console.WriteLine("Items: ");
                    foreach (var i in items)
                    {
                        Console.WriteLine(i);
                    }
                    break;
                case 6:
                    Console.WriteLine("Mobs: ");
                    foreach (var i in mobs)
                    {
                        Console.WriteLine(i);
                    }
                    break;
                case 7:
                    Environment.Exit(0);
                    break;
            }
        }
        
        public static void options()
        {
            Console.WriteLine("Options incude: " +
                "\nNorth or n to move north." +
                "\nSouth or s to move south." +
                "\nPosition to show current room." +
                "\nMain Menu to show the main menu." +
                "\nOptions to get this list again.");
        }       
    }
}
