﻿/**
* 5/3/20
* CSC 153
* Brandon Dalton
* Preferred customer class 
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PerferredCustomerClassLib;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            List<PerferredCustomer> customers = new List<PerferredCustomer>();
            customers.Add(new PerferredCustomer("Bob", "123 drive", "10101010", "0001", true, 2000));
            customers.Add(new PerferredCustomer("Sherry", "124 drive", "20202020", "0002", true, 1510));
            customers.Add(new PerferredCustomer("Thor", "125 drive", "30303030", "0003", true, 1200));
            customers.Add(new PerferredCustomer("Liz", "126 drive", "50505050", "0004", true, 600));
            customers.Add(new PerferredCustomer("Gary", "127 drive", "40404040", "0005", false, 100));

            foreach (PerferredCustomer customer in customers)
            {
                Console.WriteLine($"Name - {customer.Name}, Address - {customer.Address}, Phone - {customer.PhoneNumber}, Customer Number - {customer.CustomerNumber}, Mailing List - {customer.MailingList}, Purchases - ${customer.Purchase}, Discount - {customer.Discount}%");
                Console.WriteLine("");
            }

            Console.ReadLine();
        }
    }
}
