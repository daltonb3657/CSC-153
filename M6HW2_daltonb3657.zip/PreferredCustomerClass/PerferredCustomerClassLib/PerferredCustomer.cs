﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PerferredCustomerClassLib
{
    public class PerferredCustomer : Customer
    {
        // Fields
        private int _purchase;
        private int _discount;

        // Constructor
        public PerferredCustomer()
        {
            Name = "No Name";
            Address = "No Address";
            PhoneNumber = "No Phone Number";
            CustomerNumber = "No customer number";
            MailingList = false;
            Purchase = 0;
            Discount = 0;
        }
        public PerferredCustomer(string name, string address, string phoneNumb, string customerNumb, bool mailingList, int purchase)
        {
            Name = name;
            Address = address;
            PhoneNumber = phoneNumb;
            CustomerNumber = customerNumb;
            MailingList = mailingList;
            Purchase = purchase;
            Discount = DiscountRate(Purchase);
        }

        // Properties
        public int Purchase
        {
            get
            {
                return _purchase;
            }
            set
            {
                _purchase = value;
            }
        }
        
        public int Discount
        {
            get
            {
                return _discount;
            }
            set
            {
                _discount = value;
            }
        }

        // Mehtod

        public static int DiscountRate(int purchase)
        {
            if (purchase >= 2000)
            {
                return 10;
            }
            else if(purchase >= 1500 && purchase< 2000)
            {
                return 7;
            }
            else if (purchase >= 1000 && purchase< 1500)
            {
                return 6;
            }
            else if (purchase >= 500 && purchase < 1000)
            {
                return 5;
            }
            else
            {
                return 0;
            }
        }
    }
}
