﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PerferredCustomerClassLib
{
    public class Customer : Person
    {
        // Fields
        private string _customerNumber;
        private bool _mailingList;
        // Constructor
        public Customer()
        {
            Name = "No Name";
            Address = "No Address";
            PhoneNumber = "No Phone Number";
            CustomerNumber = "No customer number";
            MailingList = false;
        }
        public Customer(string name, string address, string phoneNumber, string customerNumber, bool mailingList)
        {
            Name = name;
            Address = address;
            PhoneNumber = phoneNumber;
            CustomerNumber = customerNumber;
            MailingList = mailingList;
        }
        // Properties
        public string CustomerNumber
        {
            get
            {
                return _customerNumber;
            }
            set
            {
                _customerNumber = value;
            }
        }
        public bool MailingList
        {
            get
            {
                return _mailingList;
            }
            set
            {
                _mailingList = value;
            }
        }
    }
}
