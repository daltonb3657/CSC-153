﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailItemClassLib
{
   public static class StandardMessages
    {
        public static string DisplayHeader()
        {
            return "Description, Units on Hand, Price";
        }
        public static string ShowItem(RetailItem inputItem)
        {
            return $"{inputItem.Description}, {inputItem.UnitsOnHand}, ${inputItem.Price}";
        }
    }
}
