﻿/**
* 3/25/20
* CSC 153
* Brandon Dalton
* This program creates a list of objects and displays them and their properties
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailItemClassLib;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            
            List<RetailItem> items = new List<RetailItem>();
            items.Add(new RetailItem("Jacket", 12, 59.05));
            items.Add(new RetailItem("Jeans", 40, 34.95));
            items.Add(new RetailItem("Shirt", 20, 24.95));

            Console.WriteLine(StandardMessages.DisplayHeader());
            foreach(var x in items)
            {
                Console.WriteLine(StandardMessages.ShowItem(x));
            }

            Console.ReadLine();





        }
    }
}
