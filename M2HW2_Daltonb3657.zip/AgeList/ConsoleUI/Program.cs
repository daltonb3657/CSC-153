﻿/**
* 1/27/2020
* CSC 153
* Brandon Dalton
* Asks the user how many ages they want to enter and returns the ages entered
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //Holds user input
            String input;
            
            //Start menu loop
            do
            {
                //Ask user if they want to run or exit the prorgram
                Console.Write("Do you want to run the program or exit?(Please enter run or exit.) ");
                input = Console.ReadLine();
                //Converts answer to lower case to be tested for input validation
                input = input.ToLower();
                //while loop for input validation            
                while (!(input.Equals("run") || input.Equals("exit")))
                {
                    Console.Write("Error please enter run or exit!");
                    input = Console.ReadLine();
                    input = input.ToLower();
                }
                //switch statement either runs the program or exits based on what user inputs at menu
                switch (input)
                {
                    case "run":
                        //calls the runProgram method that holds the program
                        runProgram();
                        break;
                    case "exit":
                        //exits the program cleanly
                        Environment.Exit(0);
                        break;
                }
            } while (input.Equals("run"));
            
        }
        public static void runProgram()
        {
            //holds the number of ages the user wants to enter
            int ageNumber=0;
            
            //holds input from user, set to null to use in while loop for validation
            String input=null;
            while (input == null)
            {
                Console.Write("How many ages are you entering? ");

                //try catch statement to validate if a number was entered so program doesn't crash
                try
                {
                    input = Console.ReadLine();
                    ageNumber = int.Parse(input);
                }
                catch (FormatException e)
                {
                    //gives user an error if an integer wasn't entered and resets input to null so loop will run again
                    Console.WriteLine("Error! Please enter a number!");
                    input = null;
                }
            }
            //array to hold the ages the user enters
            List<int> ages = new List<int>();            
            for (int i=0;i<ageNumber;i++)
            {
                input = null;
                //input validation loop to make sure an integer was entered
                //tests the input for validation
                while (input == null)
                {
                    Console.Write("Please enter an age: ");
                    try
                    {
                        input = Console.ReadLine();
                        ages.Add(int.Parse(input));
                    }
                    catch (FormatException e)
                    {
                        Console.WriteLine("Error! Please enter a number!");
                        input = null;
                    }
                    
                    
                }
                
            }

            //displays the ages in the array and adds the ages together
            int ageTotal=0;
            int ageAverage;
            for(int i=0;i<ages.Count;i++)
            {
                Console.WriteLine(ages[i]);
                ageTotal = ageTotal + ages[i];
            }
            ageAverage = ageTotal / ageNumber;
            Console.WriteLine($"Average of the ages entered: { ageAverage}");

        }

    }
}
